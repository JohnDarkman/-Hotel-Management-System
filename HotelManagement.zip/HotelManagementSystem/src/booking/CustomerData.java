/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package booking;

/**
 *
 * @author User
 */
public class CustomerData {
    public static final String DELIM = ",";

    String name;
    String passport;
    String contact;
    String email;
    String room;
    String duration;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassport() {
        return passport;
    }

    public void setPassport(String passport) {
        this.passport = passport;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
    
    public void loadString(String data) {
        int i = 2;
        String[] parts = data.split(DELIM);
        setName(parts[i+0]);
        setPassport(parts[i+1]);
        setContact(parts[i+2]);
        setEmail(parts[i+3]);
        setRoom(parts[i+4]);
        setDuration(parts[i+5]);
    }
    
    @Override
    public String toString() {
        return name+DELIM
                +passport+DELIM
                +contact+DELIM
                +email+DELIM
                +room+DELIM
                +duration+DELIM;
    }
}
