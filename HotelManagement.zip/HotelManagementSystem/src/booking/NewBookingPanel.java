/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package booking;

import filehandler.FileHandler;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class NewBookingPanel extends javax.swing.JPanel {
    // filepath to database
    private final String BOOK_ROOM_LOOKUP_PATH = "./data/bookroom.txt";
    private final String CUSTOMER_LOOKUP_PATH = "./data/customerDetail.txt";
    
    // jList Model
    final DefaultListModel<String> roomListModel = new DefaultListModel();
    
    // formula for date
    private static final long MILLIS_IN_A_DAY = 1000 * 60 * 60 * 24;

    // eager initialization
    RoomData roomData = new RoomData();
    RoomData otherData = new RoomData();
    CustomerData customerData = new CustomerData();
    ViewReceiptForm receipt = new ViewReceiptForm();
    
    /**
     * Creates new form BookingPanel
     */
    public NewBookingPanel() {
        initComponents();
        designPanel();
        
        // setup jList Model
        roomList.setModel(roomListModel);
    }

    private boolean validate(String data) {
        // validate string input for textfield
        return data!=null && !data.isEmpty();
    }
    
    private static Date findNextDay(Date date) {
        return new Date(date.getTime() + MILLIS_IN_A_DAY);
    }

    
    private void updateDb() {
        // verify and update database here
        
        // Update Book Room
        String duration = durationTextField.getText();
        Date date =  dateChooser.getDate();
        String room = roomList.getSelectedValue();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        int roomNum = Integer.parseInt(room.substring(5))-1;

        // loop for duration
        for (int i=0; i<Integer.parseInt(duration); i++) {
            // init other date and initialize
            roomData.loadString(FileHandler.loadData(BOOK_ROOM_LOOKUP_PATH, dateFormat.format(date)));
            roomData.setInitialDate(dateFormat.format(date));
            otherData.copyData(roomData);
            otherData.setData(roomNum, Boolean.TRUE);

            // Save Data
            FileHandler.saveFile(BOOK_ROOM_LOOKUP_PATH, roomData.toString(), otherData.toString());
            String customer = dateFormat.format(date)+CustomerData.DELIM+roomNum+CustomerData.DELIM+customerData.toString();
            FileHandler.saveFile(CUSTOMER_LOOKUP_PATH, customer, customer);

            // update date
            date =  findNextDay(date);
        }
    }
    
    private void searchDb() {
        // Search base on date chosen
        // all the data retrieve
        Date date =  dateChooser.getDate();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String dateChosen = "";
        if (date!=null)
             dateChosen = dateFormat.format(date);

        String duration = durationTextField.getText();

        if (!validate(dateChosen))
            JOptionPane.showMessageDialog(this, "Please Choose a Date", "Error!", JOptionPane.ERROR_MESSAGE);
        else if (!validate(duration))
            JOptionPane.showMessageDialog(this, "Please Enter Customer Duration", "Error!", JOptionPane.ERROR_MESSAGE);
        else if (Integer.parseInt(duration)>3)
            JOptionPane.showMessageDialog(this, "A room reservation is limited to 3 days only", "Limit!", JOptionPane.ERROR_MESSAGE);
        
        else {            
            // Update Next Date
            Date nextDate =  findNextDay(date);
            String nextDateChosen = dateFormat.format(nextDate);

            // Initialize Data
            roomData.setInitialDate(dateChosen);
            roomData.loadString(FileHandler.loadData(BOOK_ROOM_LOOKUP_PATH, dateChosen));

            // loop for duration
            for (int i=0; i<Integer.parseInt(duration)-1; i++) {
                // init other date and initialize
                otherData.loadString(FileHandler.loadData(BOOK_ROOM_LOOKUP_PATH, nextDateChosen));
                roomData.update(otherData);
                
                // Update Next Date
                nextDate =  findNextDay(date);
                nextDateChosen = dateFormat.format(nextDate);
            }
            
            // Display Available Room
            roomListModel.clear();
            for (int i=0; i<roomData.getData().size(); i++) {
                if (!roomData.getData(i))
                    roomListModel.addElement("Room "+(i+1));
            }
        }
    }
    
    private void designPanel() {
        // design for the panel
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        dateLabel = new javax.swing.JLabel();
        dateChooser = new com.toedter.calendar.JDateChooser();
        durationLabel = new javax.swing.JLabel();
        durationTextField = new javax.swing.JTextField();
        searchButton = new javax.swing.JButton();
        nameLabel = new javax.swing.JLabel();
        nameTextField = new javax.swing.JTextField();
        passportLabel = new javax.swing.JLabel();
        passportTextField = new javax.swing.JTextField();
        contactLabel = new javax.swing.JLabel();
        contactTextField = new javax.swing.JTextField();
        emailLabel = new javax.swing.JLabel();
        emailTextField = new javax.swing.JTextField();
        submitButton = new javax.swing.JButton();
        roomPane = new javax.swing.JScrollPane();
        roomList = new javax.swing.JList<>();
        titleLabel = new javax.swing.JLabel();

        setLayout(new java.awt.GridBagLayout());

        dateLabel.setText("Select Date");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        add(dateLabel, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 100;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        add(dateChooser, gridBagConstraints);

        durationLabel.setText("Duration");
        durationLabel.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 40;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.LINE_START;
        gridBagConstraints.insets = new java.awt.Insets(0, 30, 0, 0);
        add(durationLabel, gridBagConstraints);

        durationTextField.setText("1");
        durationTextField.setPreferredSize(new java.awt.Dimension(70, 26));
        durationTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numOnly(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        add(durationTextField, gridBagConstraints);

        searchButton.setBackground(new java.awt.Color(51, 153, 255));
        searchButton.setText("Search");
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        add(searchButton, gridBagConstraints);

        nameLabel.setText("Name");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(30, 0, 0, 0);
        add(nameLabel, gridBagConstraints);

        nameTextField.setText("Name");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 70;
        gridBagConstraints.insets = new java.awt.Insets(30, 0, 0, 0);
        add(nameTextField, gridBagConstraints);

        passportLabel.setText("IC/Passport");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(passportLabel, gridBagConstraints);

        passportTextField.setText("IC/Passport");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(passportTextField, gridBagConstraints);

        contactLabel.setText("Contact");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(contactLabel, gridBagConstraints);

        contactTextField.setText("Contact");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(contactTextField, gridBagConstraints);

        emailLabel.setText("Email");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 30, 0);
        add(emailLabel, gridBagConstraints);

        emailTextField.setText("Email");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 30, 0);
        add(emailTextField, gridBagConstraints);

        submitButton.setBackground(new java.awt.Color(0, 204, 204));
        submitButton.setText("Submit");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        add(submitButton, gridBagConstraints);

        roomPane.setViewportView(roomList);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 10;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(10, 30, 10, 0);
        add(roomPane, gridBagConstraints);

        titleLabel.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        titleLabel.setText("Book Now!");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 30, 0);
        add(titleLabel, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        // all the data retrieve
        Date date =  dateChooser.getDate();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String dateChosen = "";
        if (date!=null)
             dateChosen = dateFormat.format(date);

        String name = nameTextField.getText();
        String passport = passportTextField.getText();
        String contact = contactTextField.getText();
        String email = emailTextField.getText();
        String room = roomList.getSelectedValue();
        String duration = durationTextField.getText();

        // check data valid
        if(
            validate(dateChosen) && validate(name) && 
                validate(passport) && validate(contact) && 
                validate(email) && validate(room) && validate(duration)
        ){
            // update customer
            customerData.setName(name);
            customerData.setPassport(passport);
            customerData.setContact(contact);
            customerData.setEmail(email);
            customerData.setRoom(room);
            customerData.setDuration(duration);

            // update db
            updateDb();
            JOptionPane.showMessageDialog(this, "Customer "+name+" has registered successfully!", "Registered!", JOptionPane.INFORMATION_MESSAGE);

            // display receipt
            receipt.setData(customerData);
            receipt.setVisible(true);
            
            // reset search
            searchDb();
        }
        else {
            // display error depends on occassion
            if (!validate(dateChosen))
                JOptionPane.showMessageDialog(this, "Please Choose a Date", "Error!", JOptionPane.ERROR_MESSAGE);
            else if (!validate(name))
                JOptionPane.showMessageDialog(this, "Please Enter Customer Name", "Error!", JOptionPane.ERROR_MESSAGE);
            else if (!validate(passport))
                JOptionPane.showMessageDialog(this, "Please Enter Customer IC/Passport", "Error!", JOptionPane.ERROR_MESSAGE);
            else if (!validate(contact))
                JOptionPane.showMessageDialog(this, "Please Enter Customer Contact Number", "Error!", JOptionPane.ERROR_MESSAGE);
            else if (!validate(email))
                JOptionPane.showMessageDialog(this, "Please Enter Customer Email", "Error!", JOptionPane.ERROR_MESSAGE);
            else if (!validate(room))
                JOptionPane.showMessageDialog(this, "Please Enter Customer Room Chosen", "Error!", JOptionPane.ERROR_MESSAGE);
            else if (!validate(duration))
                JOptionPane.showMessageDialog(this, "Please Enter Customer Duration", "Error!", JOptionPane.ERROR_MESSAGE);
        }        
    }//GEN-LAST:event_submitButtonActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        searchDb();
    }//GEN-LAST:event_searchButtonActionPerformed

    private void numOnly(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numOnly
        // Make sure text field input number only
        char enter = evt.getKeyChar();
        if(!(Character.isDigit(enter))){
            evt.consume();
        }
    }//GEN-LAST:event_numOnly


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel contactLabel;
    private javax.swing.JTextField contactTextField;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JLabel durationLabel;
    private javax.swing.JTextField durationTextField;
    private javax.swing.JLabel emailLabel;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JTextField nameTextField;
    private javax.swing.JLabel passportLabel;
    private javax.swing.JTextField passportTextField;
    private javax.swing.JList<String> roomList;
    private javax.swing.JScrollPane roomPane;
    private javax.swing.JButton searchButton;
    private javax.swing.JButton submitButton;
    private javax.swing.JLabel titleLabel;
    // End of variables declaration//GEN-END:variables
}
