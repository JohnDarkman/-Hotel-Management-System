/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package booking;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class RoomData {
    private final String DELIM = ",";

    String initialDate;
    ArrayList<Boolean> isBook = new ArrayList<>(20);

    public RoomData() {
        // initialize ArrayList
        for(int i=0; i<20; i++)
            isBook.add(Boolean.FALSE);
    }
    
    public String getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(String initialDate) {
        this.initialDate = initialDate;
    }

    public ArrayList<Boolean> getData() {
        return isBook;
    }

    public Boolean getData(int index) {
        return isBook.get(index);
    }

    public void setData(ArrayList<Boolean> isBook) {
        this.isBook = isBook;
    }
    
    public void setData(int index, Boolean data) {
        isBook.set(index, data);
    }
    
    public void copyData(RoomData other) {
        setInitialDate(other.getInitialDate());
        for (int i=0; i<isBook.size(); i++)
            setData(i, (other.getData(i)));
    }
    
    public void update(RoomData other) {
        setInitialDate(initialDate);
        for (int i=0; i<isBook.size(); i++)
            setData(i, (isBook.get(i)||other.getData(i)));
    }
    
    public void loadString(String data) {
        if (!data.equals("Data not found")) {
            String[] parts = data.split(DELIM);
            setInitialDate(parts[0]);
            for (int i=0; i<isBook.size(); i++)
                isBook.set(i, Boolean.valueOf(parts[i+1]));
        }
        else {
            // init with zeros
            for (int i=0; i<isBook.size(); i++)
                isBook.set(i, Boolean.FALSE);
        }
    }

    @Override
    public String toString() {
        String data = initialDate + DELIM;
        for (int i=0; i<isBook.size(); i++) 
            data += isBook.get(i)+DELIM;
        return data;
    }
}
