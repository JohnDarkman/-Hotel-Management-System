/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filehandler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author User
 */
public class FileHandler {
    // eager singleton initialization
    FileHandler handler = new FileHandler();

    private FileHandler() {}
    public FileHandler getHandler() {
        return handler;
    }
    
    public static boolean checkDataExists(String path, String lookupData) {
        try {
            File file;
            file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            boolean found;
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                found = false;
                while ((line = reader.readLine()) != null) {
                    if (line.contains(lookupData)) {
                        found = true;
                        break;
                    }
                }
            }
            return found;
        } catch (IOException e) {
            return false;
        }
    }
    
    public static void saveFile(String path, String lookupData, String newData) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            StringBuilder fileContent;
            boolean found;
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                fileContent = new StringBuilder();
                found = false;
                while ((line = reader.readLine()) != null) {
                    if (line.contains(lookupData)) {
                        line = line.replace(lookupData, newData);
                        found = true;
                    }
                    fileContent.append(line).append("\n");
                }
            }
            if (!found) {
                fileContent.append(newData).append("\n");
            }
            try (FileWriter writer = new FileWriter(file)) {
                String data = fileContent.toString();
                writer.write(data);
            }
        } catch (IOException e) {
        }
    }
    
    public static String loadData(String path, String lookupData) {
        try {
            File file = new File(path);
            if (!file.exists()) {
                file.createNewFile();
            }
            StringBuilder fileContent;
            boolean found;
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                fileContent = new StringBuilder();
                found = false;
                while ((line = reader.readLine()) != null) {
                    if (line.contains(lookupData)) {
                        fileContent.append(line);
                        found = true;
                        break;
                    }
                }
            }
            if (!found) {
                fileContent.append("Data not found");
            }
            return fileContent.toString();
        } catch (IOException e) {
            return "Error occurred while loading data";
        }
    }
}
