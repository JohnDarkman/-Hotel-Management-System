/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package auth;

/**
 *
 * @author User
 */
public final class AuthData {
    private final String DELIM = ",";
    String staffId;
    String password;

    public AuthData() {}
    public AuthData(String data) {
        loadString(data);
    }
    public AuthData(String staffId, String password) {
        setStaffId(staffId);
        setPassword(password);
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean verify(AuthData other) {
        return getStaffId().equals(other.getStaffId()) 
                && getPassword().equals(other.getPassword());
    }
    
    public void loadString(String data) {
        String[] parts = data.split(DELIM);
        setStaffId(parts[0]);
        setPassword(parts[1]);
    }

    @Override
    public String toString() {
        return getStaffId() + DELIM
                + getPassword() + DELIM;
    }
}